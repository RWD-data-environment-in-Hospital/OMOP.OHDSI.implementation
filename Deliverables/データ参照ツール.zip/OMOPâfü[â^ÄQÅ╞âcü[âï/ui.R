## ui.R ##
source('ui_DataList.R', local = TRUE, encoding="utf-8")

dashboardPage(
  dashboardHeader(title = "OMOP DASHBOAD"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("OMOP DATA LIST", icon=icon("th-list"), tabName = 'DataList'
      )
    )    
  ),
  dashboardBody(
    tabItems(
      tabItem_DataList
    )
  ),
  skin="blue"
)