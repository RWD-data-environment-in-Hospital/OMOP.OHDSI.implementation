source('javaScript.R', local = TRUE, encoding="utf-8")

tabItem_DataList <- tabItem(
  "DataList",
  
  tags$head(
    tags$link(rel="stylesheet",type="text/css",href="style.css")
  ),
  tags$script(HTML(strJavascript01)),
  
  # アプリケーションタイトル
  titlePanel("OMOP Data List"),
  
  inputPanel(

  # レジメンリスト
    selectInput("p_nm", 
                label = "パス名", 
                choices = ""),
  # 病名リスト
    selectInput("d_nm", 
                label = "病名", 
                choices = ""),
  # 表示ボタン
    actionButton("search", 
                 label="表示", 
                 class="searchbutton"),

  # 件数ボタン
  # numericInput("count", 
  #              label = "ページあたり件数(10～20)",
  #              value=20, 
  #              min=10,  
  #              max=20, 
  #              step=1, 
  #              width="50%"
  #             ),

    textOutput("result"),

    textOutput("test01"),
    textOutput("test02"),
    textOutput("test03"),
    textOutput("test04"),
    textOutput("test05"),
    textOutput("test06"),
    textOutput("test07")
  ),
  
  plotOutput("barplot1",height="640px"),
  plotOutput("barplot2",height="640px"),
  plotOutput("barplot3",height="640px"),
  plotOutput("barplot4",height="640px"),
  plotOutput("barplot5",height="640px"),
  plotOutput("barplot6",height="640px"),
  plotOutput("barplot7",height="640px"),
  plotOutput("barplot8",height="640px"),
  plotOutput("barplot9",height="640px"),
  plotOutput("barplot10",height="640px"),
  
)

