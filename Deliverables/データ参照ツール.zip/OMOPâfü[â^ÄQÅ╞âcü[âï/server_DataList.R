#
  library(DBI)
  library(RPostgreSQL)

# 初期表示
  observe({
    con <- dbConnect(PostgreSQL(), 
                     host="127.0.0.1", 
                     user= "postgres", 
                     password="NCCE2021!", 
                     dbname="postgres"
                    )

    PatnmList <- dbGetQuery(con,
                            "SELECT CONCEPT_NAME AS PATH_NAME 
                             FROM CONCEPT 
                             WHERE DOMAIN_ID='Regimen'")
    DisnmList <- dbGetQuery(con,
                            "SELECT CONCEPT_NAME AS DISEASE_NAME 
                             FROM CONCEPT 
                             WHERE DOMAIN_ID='Condition'")

    dbDisconnect(con)

    PatnmList <- t(PatnmList)
    DisnmList <- t(DisnmList)
    updateSelectInput(session, "p_nm", choices = PatnmList)
    updateSelectInput(session, "d_nm", choices = DisnmList)
  })


#
  observeEvent(input$search, {
    i_patnm <- input$p_nm
    output$test_p_id <- renderText(i_patnm)

    con <- dbConnect(PostgreSQL(), 
                     host="127.0.0.1", 
                     user= "postgres", 
                     password="NCCE2021!", 
                     dbname="postgres"
                    )
  #
    tSqlStrP <- paste("SELECT CONCEPT_ID FROM CONCEPT WHERE CONCEPT_NAME='", input$p_nm,"'", sep="")
    sPath_id <- dbGetQuery(con, tSqlStrP)
    sPath_id <- t(sPath_id)
  # sPath_id <- 2005000001
    output$test01 <- renderText(sPath_id)
  #
    tSqlStrD <- paste("SELECT CONCEPT_ID FROM CONCEPT WHERE CONCEPT_NAME='", input$d_nm,"'", sep="")
    sDiss_cd <- dbGetQuery(con, tSqlStrD)
    sDiss_cd <- t(sDiss_cd)
  # sDiss_cd <- 2001000001
    output$test02 <- renderText(sDiss_cd)
  # 
  # (CONCEPT_NAME || ' ('  || DOSE_UNIT_SOURCE_VALUE || ')') AS DNAME, 
    tSqlStrG <- paste("SELECT 
                         DRUG_CONCEPT_ID, 
                         CONCEPT_NAME, 
                         DOSE_UNIT_SOURCE_VALUE, 
                         SUM(QUANTITY) AS TQUANTITY
                       FROM 
                         DRUG_EXPOSURE AS DE
                       INNER JOIN 
                       ( SELECT 
                           CO.PERSON_ID
                         FROM 
                           CONDITION_OCCURRENCE AS CO 
                         INNER JOIN 
                           PROCEDURE_OCCURRENCE AS PO 
                         ON 
                           CO.PERSON_ID = PO.PERSON_ID 
                         WHERE
                           CO.CONDITION_CONCEPT_ID=", sDiss_cd, 
                      "  AND 
                           PO.PROCEDURE_CONCEPT_ID=", sPath_id,
                      ") AS CP
                       ON 
                         DE.PERSON_ID=CP.PERSON_ID
                       LEFT JOIN 
                         CONCEPT AS CN
                       ON 
                         DE.DRUG_CONCEPT_ID=CN.CONCEPT_ID
                       GROUP BY 
                         DRUG_CONCEPT_ID, CONCEPT_NAME, DOSE_UNIT_SOURCE_VALUE
                       ORDER BY 
                         TQUANTITY desc",
                      sep="")
    
  # 
    QuantList <- dbGetQuery(con, tSqlStrG)
    tQuantList <- t(QuantList)
    vQuantList <- matrix(as.matrix(tQuantList), nrow(tQuantList), ncol(tQuantList))
    dimnames(vQuantList) <- NULL
    dbDisconnect(con)

    if (ncol(tQuantList) > 0)  # 対象レコードありの場合
    {
      if (ncol(tQuantList) > 100)  # 100件以上の場合
      {
        output$result <- renderText("先頭100件のレコードを表示します。")
      }
      else  # 100件以下の場合
      {
        output$result <- renderText(paste(ncol(tQuantList), "件のレコードを表示します。", sep=""))
      }

    # 読み込んだレコード全体をベクトル変換
      oQuantList <- as.numeric(vQuantList[4,])  # 投与量集計値
      oDunitList <- vQuantList[3,]  # 単位
      oDnameList <- vQuantList[2,]  # 薬品名
      NofList <- length(oQuantList) # 全体要素数
      
    # グラフ基本情報定義
      cElemPPg <- 4    # グラフ内の要素数
      cXlimNum <- c(0,max(oQuantList)*1.5)    # 横軸の最大目盛り
      cQuantPos <- max(oQuantList)*0.008      # 総量数値表示位置
      cUnitPos <- max(oQuantList)*0.07        # 単位の表示位置
      cDnamPos <- max(oQuantList)*0.12        # 薬品名表示位置
      cDmyList <- c( "", "　", "　", "")      # 表示幅調整用ダミー
      
    # グラフ描画開始

    # グラフ１ #################
    # グラフ１出力範囲確認 #####
      j <- 1
      if (NofList > (cElemPPg * j))  # 1ページ以上ある場合
      { wGrpElem1 <- cElemPPg                 # データあり件数
        wStrtEl1 <- (cElemPPg * (j - 1)) + 1  # 抽出開始位置
        wEndeEl1 <- cElemPPg * j              # 抽出終了位置
      }
      else   # 1ページに収まる場合
      { wGrpElem1 <- NofList-(cElemPPg * (j - 1)) # データあり件数
        wStrtEl1 <- (cElemPPg * (j - 1)) + 1  #  抽出開始位置
        wEndeEl1 <- NofList                   #  抽出終了位置
      }
      output$test03 <- renderText(wGrpElem1)  # デバッグ用
      
    # グラフ１出力 #####
      if (wGrpElem1 > 0)  # 表示レコードあり
      {
      # 表示分抽出
        srtQuantList1 <- matrix(as.matrix(tQuantList[,wStrtEl1:wEndeEl1]), nrow(tQuantList), wGrpElem1)

      # データ件数不足分はダミーデータで埋める
        if ((cElemPPg-wGrpElem1) > 0)
        {
          for(i in 1:(cElemPPg-wGrpElem1))
            srtQuantList1 <- cbind(srtQuantList1,cDmyList)
        }

      # 表示データ並び替え
        srtQuantMtrx1 <- srtQuantList1[,order(srtQuantList1[4,],decreasing=FALSE)]

      # マトリクス->ベクトル
        oQuantList1 <- as.numeric(srtQuantMtrx1[4,])
        oDunitList1 <- srtQuantMtrx1[3,]
        oDnameList1 <- srtQuantMtrx1[2,]
  
        output$barplot1 <- renderPlot({
      # GRAPH 
      # bp1 <- barplot(height=oQuantList1[1:wGrpElem1], # ダミーデータも含めて出力する
        bp1 <- barplot(height=oQuantList1[1:cElemPPg],
                      #width=rep(5, wGrpElem1),
                      #names.arg=oDnameList1,
                      #las=2,
                       horiz=T,
                       xlim=cXlimNum,
                      #ylab="DRUG_NAME",
                       xlab="QUANTITY"
                     )
      # DISPLAY QUANTITY
      # for(i in 1:wGrpElem1) text(oQuantList1[i]+cQuantPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList1[i]+cQuantPos,
                                  bp1[i],
                                  pos=4,
                                  oQuantList1[i], 
                                 #family="fontname",
                                  cex=1.0)
      # DISPLAY UNIT
      # for(i in 1:wGrpElem1) text(oQuantList1[i]+cUnitPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList1[i]+cUnitPos, 
                                  bp1[i],
                                  pos=4,
                                  paste("[", oDunitList1[i], "]", sep=""), 
                                 #family="fontname",
                                  cex=1.0)
      # DISPLAY DRUG_NAME
      # for(i in 1:wGrpElem1) text(oQuantList1[i]+cDnamPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList1[i]+cDnamPos, 
                                  bp1[i],
                                  pos=4,
                                  oDnameList1[i], 
                                 #family="fontname",
                                  cex=1.0)
        })
      }
      else
      {
        output$barplot1 <- renderPlot(plot.new())
      }
  
    # グラフ２ #################
    # グラフ２出力範囲確認 #####
      j <- 2
      if (NofList > (cElemPPg * j))  # 1ページ以上ある場合
      { wGrpElem2 <- cElemPPg                 # データあり件数
        wStrtEl2 <- (cElemPPg * (j - 1)) + 1  # 抽出開始位置
        wEndeEl2 <- cElemPPg * j              # 抽出終了位置
      }
      else   # 1ページに収まる場合
      { wGrpElem2 <- NofList-(cElemPPg * (j - 1)) # データあり件数
        wStrtEl2 <- (cElemPPg * (j - 1)) + 1  #  抽出開始位置
        wEndeEl2 <- NofList                   #  抽出終了位置
      }
      output$test04 <- renderText(wGrpElem2)  # デバッグ用
  
    # グラフ２出力 #####
      if (wGrpElem2 > 0)  # 表示レコードあり
      {
      # 表示分抽出
        srtQuantList2 <- matrix(as.matrix(tQuantList[,wStrtEl2:wEndeEl2]), nrow(tQuantList), wGrpElem2)

      # データ件数不足分はダミーデータで埋める
        if ((cElemPPg-wGrpElem2) > 0)
        {
          for(i in 1:(cElemPPg-wGrpElem2))
            srtQuantList2 <- cbind(srtQuantList2,cDmyList)
        }

      # 表示データ並び替え
        srtQuantMtrx2 <- srtQuantList2[,order(srtQuantList2[4,],decreasing=FALSE)]
       
      # マトリクス->ベクトル
        oQuantList2 <- as.numeric(srtQuantMtrx2[4,])
        oDunitList2 <- srtQuantMtrx2[3,]
        oDnameList2 <- srtQuantMtrx2[2,]
  
        output$barplot2 <- renderPlot({
      # GRAPH 
      # bp2 <- barplot(height=oQuantList2[1:wGrpElem2], # ダミーデータも含めて出力する
        bp2 <- barplot(height=oQuantList2[1:cElemPPg],
                      #width=rep(5, wGrpElem2),
                      #names.arg=oDnameList,
                      #las=2,
                       horiz=T,
                       xlim=cXlimNum,
                      #ylab="DRUG_NAME",
                       xlab="QUANTITY"
                     )
      # DISPLAY QUANTITY
      # for(i in 1:wGrpElem2) text(oQuantList2[i]+cQuantPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList2[i]+cQuantPos,
                                  bp2[i],
                                  pos=4,
                                  oQuantList2[i], 
                                 #family="fontname",
                                  cex=1.0)
      # DISPLAY UNIT
      # for(i in 1:wGrpElem2) text(oQuantList2[i]+cUnitPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList2[i]+cUnitPos, 
                                  bp2[i],
                                  pos=4,
                                  paste("[", oDunitList2[i], "]", sep=""), 
                                 #family="fontname",
                                  cex=1.0)
      # DISPLAY DRUG_NAME
      # for(i in 1:wGrpElem2) text(oQuantList2[i]+cDnamPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList2[i]+cDnamPos, 
                                  bp2[i],
                                  pos=4,
                                  oDnameList2[i], 
                                 #family="fontname",
                                  cex=1.0)
        })
      }
      else
      {
        output$barplot2 <- renderPlot(plot.new())
      }
  
    # グラフ３ #################
    # グラフ３出力範囲確認 #####
      j <- 3
      if (NofList > (cElemPPg * j))  # 1ページ以上ある場合
      { wGrpElem3 <- cElemPPg                 # データあり件数
        wStrtEl3 <- (cElemPPg * (j - 1)) + 1  # 抽出開始位置
        wEndeEl3 <- cElemPPg * j              # 抽出終了位置
      }
      else   # 1ページに収まる場合
      { wGrpElem3 <- NofList-(cElemPPg * (j - 1)) # データあり件数
        wStrtEl3 <- (cElemPPg * (j - 1)) + 1  #  抽出開始位置
        wEndeEl3 <- NofList                   #  抽出終了位置
      }
      output$test05 <- renderText(wGrpElem3)  # デバッグ用
  
    # グラフ３出力 #####
      if (wGrpElem3 > 0)  # 表示レコードあり
      {
      # 表示分抽出
        srtQuantList3 <- matrix(as.matrix(tQuantList[,wStrtEl3:wEndeEl3]), nrow(tQuantList), wGrpElem3)

      # データ件数不足分はダミーデータで埋める
        if ((cElemPPg-wGrpElem3) > 0)
        {
          for(i in 1:(cElemPPg-wGrpElem3))
            srtQuantList3 <- cbind(srtQuantList3,cDmyList)
        }

      # 表示データ並び替え
        srtQuantMtrx3 <- srtQuantList3[,order(srtQuantList3[4,],decreasing=FALSE)]
       
      # マトリクス->ベクトル
        oQuantList3 <- as.numeric(srtQuantMtrx3[4,])
        oDunitList3 <- srtQuantMtrx3[3,]
        oDnameList3 <- srtQuantMtrx3[2,]
  
        output$barplot3 <- renderPlot({
      # GRAPH 
      # bp3 <- barplot(height=oQuantList3[1:wGrpElem3], # ダミーデータも含めて出力する
        bp3 <- barplot(height=oQuantList3[1:cElemPPg],
                      #width=rep(5, wGrpElem3),
                      #names.arg=oDnameList,
                      #las=2,
                       horiz=T,
                       xlim=cXlimNum,
                      #ylab="DRUG_NAME",
                       xlab="QUANTITY"
                     )
      # DISPLAY QUANTITY
      # for(i in 1:wGrpElem3) text(oQuantList3[i]+cQuantPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList3[i]+cQuantPos,
                                  bp3[i],
                                  pos=4,
                                  oQuantList3[i], 
                                 #family="fontname",
                                  cex=1.0)
      # DISPLAY UNIT
      # for(i in 1:wGrpElem3) text(oQuantList3[i]+cUnitPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList3[i]+cUnitPos, 
                                  bp3[i],
                                  pos=4,
                                  paste("[", oDunitList3[i], "]", sep=""), 
                                 #family="fontname",
                                  cex=1.0)
      # DISPLAY DRUG_NAME
      # for(i in 1:wGrpElem3) text(oQuantList3[i]+cDnamPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList3[i]+cDnamPos, 
                                  bp3[i],
                                  pos=4,
                                  oDnameList3[i], 
                                 #family="fontname",
                                  cex=1.0)
        })
      }
      else
      {
        output$barplot3 <- renderPlot(plot.new())
      }
  
    # グラフ４ #################
    # グラフ４出力範囲確認 #####
      j <- 4
      if (NofList > (cElemPPg * j))  # 1ページ以上ある場合
      { wGrpElem4 <- cElemPPg                 # データあり件数
        wStrtEl4 <- (cElemPPg * (j - 1)) + 1  # 抽出開始位置
        wEndeEl4 <- cElemPPg * j              # 抽出終了位置
      }
      else   # 1ページに収まる場合
      { wGrpElem4 <- NofList-(cElemPPg * (j - 1)) # データあり件数
        wStrtEl4 <- (cElemPPg * (j - 1)) + 1  #  抽出開始位置
        wEndeEl4 <- NofList                   #  抽出終了位置
      }
      output$test06 <- renderText(wGrpElem4)  # デバッグ用
  
    # グラフ４出力 #####
      if (wGrpElem4 > 0)  # 表示レコードあり
      {
      # 表示分抽出
        srtQuantList4 <- matrix(as.matrix(tQuantList[,wStrtEl4:wEndeEl4]), nrow(tQuantList), wGrpElem4)

      # データ件数不足分はダミーデータで埋める
        if ((cElemPPg-wGrpElem4) > 0)
        {
          for(i in 1:(cElemPPg-wGrpElem4))
            srtQuantList4 <- cbind(srtQuantList4,cDmyList)
        }

      # 表示データ並び替え
        srtQuantMtrx4 <- srtQuantList4[,order(srtQuantList4[4,],decreasing=FALSE)]
       
      # マトリクス->ベクトル
        oQuantList4 <- as.numeric(srtQuantMtrx4[4,])
        oDunitList4 <- srtQuantMtrx4[3,]
        oDnameList4 <- srtQuantMtrx4[2,]
  
        output$barplot4 <- renderPlot({
      # GRAPH 
      # bp4 <- barplot(height=oQuantList4[1:wGrpElem4], # ダミーデータも含めて出力する
        bp4 <- barplot(height=oQuantList4[1:cElemPPg],
                      #width=rep(5, wGrpElem4),
                      #names.arg=oDnameList,
                      #las=2,
                       horiz=T,
                       xlim=cXlimNum,
                      #ylab="DRUG_NAME",
                       xlab="QUANTITY"
                     )
      # DISPLAY QUANTITY
      # for(i in 1:wGrpElem4) text(oQuantList4[i]+cQuantPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList4[i]+cQuantPos,
                                  bp4[i],
                                  pos=4,
                                  oQuantList4[i], 
                                 #family="fontname",
                                  cex=1.0)
      # DISPLAY UNIT
      # for(i in 1:wGrpElem4) text(oQuantList4[i]+cUnitPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList4[i]+cUnitPos, 
                                  bp4[i],
                                  pos=4,
                                  paste("[", oDunitList4[i], "]", sep=""), 
                                 #family="fontname",
                                  cex=1.0)
      # DISPLAY DRUG_NAME
      # for(i in 1:wGrpElem4) text(oQuantList4[i]+cDnamPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList4[i]+cDnamPos, 
                                  bp4[i],
                                  pos=4,
                                  oDnameList4[i], 
                                 #family="fontname",
                                  cex=1.0)
        })
      }
      else
      {
        output$barplot4 <- renderPlot(plot.new())
      }
  
    # グラフ５ #################
    # グラフ５出力範囲確認 #####
      j <- 5
      if (NofList > (cElemPPg * j))  # 1ページ以上ある場合
      { wGrpElem5 <- cElemPPg                 # データあり件数
        wStrtEl5 <- (cElemPPg * (j - 1)) + 1  # 抽出開始位置
        wEndeEl5 <- cElemPPg * j              # 抽出終了位置
      }
      else   # 1ページに収まる場合
      { wGrpElem5 <- NofList-(cElemPPg * (j - 1)) # データあり件数
        wStrtEl5 <- (cElemPPg * (j - 1)) + 1  #  抽出開始位置
        wEndeEl5 <- NofList                   #  抽出終了位置
      }
      output$test07 <- renderText(wGrpElem5)  # デバッグ用
  
    # グラフ５出力 #####
      if (wGrpElem5 > 0)  # 表示レコードあり
      {
      # 表示分抽出
        srtQuantList5 <- matrix(as.matrix(tQuantList[,wStrtEl5:wEndeEl5]), nrow(tQuantList), wGrpElem5)

      # データ件数不足分はダミーデータで埋める
        if ((cElemPPg-wGrpElem5) > 0)
        {
          for(i in 1:(cElemPPg-wGrpElem5))
            srtQuantList5 <- cbind(srtQuantList5,cDmyList)
        }

      # 表示データ並び替え
        srtQuantMtrx5 <- srtQuantList5[,order(srtQuantList5[4,],decreasing=FALSE)]
       
      # マトリクス->ベクトル
        oQuantList5 <- as.numeric(srtQuantMtrx5[4,])
        oDunitList5 <- srtQuantMtrx5[3,]
        oDnameList5 <- srtQuantMtrx5[2,]
  
        output$barplot5 <- renderPlot({
      # GRAPH 
      # bp5 <- barplot(height=oQuantList5[1:wGrpElem5], # ダミーデータも含めて出力する
        bp5 <- barplot(height=oQuantList5[1:cElemPPg],
                      #width=rep(5, wGrpElem4),
                      #names.arg=oDnameList,
                      #las=2,
                       horiz=T,
                       xlim=cXlimNum,
                      #ylab="DRUG_NAME",
                       xlab="QUANTITY"
                     )
      # DISPLAY QUANTITY
      # for(i in 1:wGrpElem5) text(oQuantList5[i]+cQuantPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList5[i]+cQuantPos,
                                  bp5[i],
                                  pos=4,
                                  oQuantList5[i], 
                                 #family="fontname",
                                  cex=1.0)
      # DISPLAY UNIT
      # for(i in 1:wGrpElem5) text(oQuantList5[i]+cUnitPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList5[i]+cUnitPos, 
                                  bp5[i],
                                  pos=4,
                                  paste("[", oDunitList5[i], "]", sep=""), 
                                 #family="fontname",
                                  cex=1.0)
      # DISPLAY DRUG_NAME
      # for(i in 1:wGrpElem5) text(oQuantList5[i]+cDnamPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList5[i]+cDnamPos, 
                                  bp5[i],
                                  pos=4,
                                  oDnameList5[i], 
                                 #family="fontname",
                                  cex=1.0)
        })
      }
      else
      {
        output$barplot5 <- renderPlot(plot.new())
      }
  
    # グラフ６ #################
    # グラフ６出力範囲確認 #####
      j <- 6
      if (NofList > (cElemPPg * j))  # 1ページ以上ある場合
      { wGrpElem6 <- cElemPPg                 # データあり件数
        wStrtEl6 <- (cElemPPg * (j - 1)) + 1  # 抽出開始位置
        wEndeEl6 <- cElemPPg * j              # 抽出終了位置
      }
      else   # 1ページに収まる場合
      { wGrpElem6 <- NofList-(cElemPPg * (j - 1)) # データあり件数
        wStrtEl6 <- (cElemPPg * (j - 1)) + 1  #  抽出開始位置
        wEndeEl6 <- NofList                   #  抽出終了位置
      }
      #output$test08 <- renderText(wGrpElem6)  # デバッグ用
  
    # グラフ６出力 #####
      if (wGrpElem6 > 0)  # 表示レコードあり
      {
      # 表示分抽出
        srtQuantList6 <- matrix(as.matrix(tQuantList[,wStrtEl6:wEndeEl6]), nrow(tQuantList), wGrpElem6)

      # データ件数不足分はダミーデータで埋める
        if ((cElemPPg-wGrpElem6) > 0)
        {
          for(i in 1:(cElemPPg-wGrpElem6))
            srtQuantList6 <- cbind(srtQuantList6,cDmyList)
        }

      # 表示データ並び替え
        srtQuantMtrx6 <- srtQuantList6[,order(srtQuantList6[4,],decreasing=FALSE)]
       
      # マトリクス->ベクトル
        oQuantList6 <- as.numeric(srtQuantMtrx6[4,])
        oDunitList6 <- srtQuantMtrx6[3,]
        oDnameList6 <- srtQuantMtrx6[2,]
  
        output$barplot6 <- renderPlot({
      # GRAPH 
      # bp6 <- barplot(height=oQuantList6[1:wGrpElem6], # ダミーデータも含めて出力する
        bp6 <- barplot(height=oQuantList6[1:cElemPPg],
                      #width=rep(5, wGrpElem4),
                      #names.arg=oDnameList,
                      #las=2,
                       horiz=T,
                       xlim=cXlimNum,
                      #ylab="DRUG_NAME",
                       xlab="QUANTITY"
                     )
      # DISPLAY QUANTITY
      # for(i in 1:wGrpElem6) text(oQuantList6[i]+cQuantPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList6[i]+cQuantPos,
                                  bp6[i],
                                  pos=4,
                                  oQuantList6[i], 
                                 #family="fontname",
                                  cex=1.0)
      # DISPLAY UNIT
      # for(i in 1:wGrpElem6) text(oQuantList6[i]+cUnitPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList6[i]+cUnitPos, 
                                  bp6[i],
                                  pos=4,
                                  paste("[", oDunitList6[i], "]", sep=""), 
                                 #family="fontname",
                                  cex=1.0)
      # DISPLAY DRUG_NAME
      # for(i in 1:wGrpElem6) text(oQuantList6[i]+cDnamPos, # ダミーデータも含めて出力する
        for(i in 1:cElemPPg) text(oQuantList6[i]+cDnamPos, 
                                  bp6[i],
                                  pos=4,
                                  oDnameList6[i], 
                                 #family="fontname",
                                  cex=1.0)
        })
      }
      else
      {
        output$barplot6 <- renderPlot(plot.new())
      }


    # グラフ描画終了
    }
    else
    {
      output$result <- renderText("表示するレコードがありません。")
      output$barplot1 <- renderPlot(plot.new())
      output$barplot2 <- renderPlot(plot.new())
      output$barplot3 <- renderPlot(plot.new())
      output$barplot4 <- renderPlot(plot.new())
      output$barplot5 <- renderPlot(plot.new())
      output$barplot6 <- renderPlot(plot.new())
    }
  # End of Procedure
  })

