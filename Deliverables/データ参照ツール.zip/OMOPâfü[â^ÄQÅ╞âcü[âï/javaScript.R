strJavascript01 <-
  "
  function id_onclick(id,data) {
    var message = {id:id,data:data};
    Shiny.onInputChange(\"jsValue\",message);
  };
"